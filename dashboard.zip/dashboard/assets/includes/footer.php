<!-- jquery js  -->
<script src="assets/js/jquery.min.js"></script>
<!-- font awesome js  -->
<script src="assets/js/all.min.js"></script>
<!-- bootstrap js  -->
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- main js  -->
<script src="assets/js/main.js"></script>

</body>

</html>